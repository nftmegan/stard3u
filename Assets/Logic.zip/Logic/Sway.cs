using UnityEngine;

public class WeaponSway : MonoBehaviour
{
    [Header("Sway Settings")]
    public float swayAmount = 0.05f;
    public float swaySmooth = 8f;
    public float maxSway = 0.06f;

    [Header("Rotation Settings")]
    public float rotationAmount = 4f;
    public float rotationSmooth = 12f;

    private Vector3 initialLocalPos;
    private Quaternion initialLocalRot;

    private Vector3 targetSwayPos;
    private Quaternion targetSwayRot;

    void Start()
    {
        initialLocalPos = transform.localPosition;
        initialLocalRot = transform.localRotation;
    }

    void Update()
    {
        // Get raw mouse delta
        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");

        // --- Position Sway ---
        Vector3 sway = new Vector3(-mouseX, -mouseY, 0f) * swayAmount;
        sway = Vector3.ClampMagnitude(sway, maxSway);
        targetSwayPos = Vector3.Lerp(targetSwayPos, sway, Time.deltaTime * swaySmooth);
        transform.localPosition = Vector3.Lerp(transform.localPosition, initialLocalPos + targetSwayPos, Time.deltaTime * swaySmooth);

        // --- Rotation Sway ---
        Quaternion swayRot = Quaternion.Euler(mouseY * rotationAmount, -mouseX * rotationAmount, 0f);
        targetSwayRot = Quaternion.Slerp(targetSwayRot, swayRot, Time.deltaTime * rotationSmooth);
        transform.localRotation = Quaternion.Slerp(transform.localRotation, initialLocalRot * targetSwayRot, Time.deltaTime * rotationSmooth);
    }
}