using UnityEngine;

[RequireComponent(typeof(Inventory))]
public class InventoryDebugUI : MonoBehaviour
{
    private Inventory inventory;
    private Vector2 scrollPos;

    [Header("Debug UI Settings")]
    public bool showInventory = true;
    public string windowTitle = "Inventory Debug";
    public Rect windowRect = new Rect(10, 10, 300, 400);

    [Header("Test Items")]
    public ItemData bowItem;
    public ItemData toolItem;
    public ItemData ammoItem;

    private void Awake()
    {
        inventory = GetComponent<Inventory>();
    }

    private void Update()
    {
        // Hotkeys to add test items
        if (Input.GetKeyDown(KeyCode.B) && bowItem != null)
            inventory.AddItem(bowItem, 1);

        if (Input.GetKeyDown(KeyCode.N) && toolItem != null)
            inventory.AddItem(toolItem, 1);

        if (Input.GetKeyDown(KeyCode.M) && ammoItem != null)
            inventory.AddItem(ammoItem, 5);

        if (Input.GetKeyDown(KeyCode.I))
            showInventory = !showInventory;
    }

    private void OnGUI()
    {
        if (!showInventory || inventory == null) return;

        windowRect = GUI.Window(123456, windowRect, DrawInventoryWindow, windowTitle);
    }

    private void DrawInventoryWindow(int windowID)
    {
        scrollPos = GUILayout.BeginScrollView(scrollPos);

        if (inventory.items.Count == 0)
        {
            GUILayout.Label("Inventory is empty.");
        }
        else
        {
            foreach (var entry in inventory.items)
            {
                if (entry.data != null)
                {
                    GUILayout.BeginHorizontal();
                    GUILayout.Label(entry.data.icon != null ? entry.data.icon.texture : Texture2D.whiteTexture, GUILayout.Width(24), GUILayout.Height(24));
                    GUILayout.Label($"{entry.data.itemName} x{entry.quantity}");
                    GUILayout.EndHorizontal();
                }
            }
        }

        GUILayout.Space(10);
        GUILayout.Label("Hotkeys: B = Bow, N = Tool, M = Ammo, I = Toggle UI");

        GUILayout.EndScrollView();
        GUI.DragWindow(new Rect(0, 0, 10000, 20));
    }
}
