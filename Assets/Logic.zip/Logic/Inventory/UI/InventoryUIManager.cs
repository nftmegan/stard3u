using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;

public class InventoryUIManager : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private InventorySlotUI[] inventorySlots;
    [SerializeField] private GameObject inventoryItemPrefab;
    [SerializeField] private RectTransform selectionHighlight;
    [SerializeField] private ToolbarSystem toolbarSystem;

    private Inventory inventory;
    private Dictionary<InventorySlotUI, InventoryItemUI> slotToItemMap = new();

    public void Initialize(Inventory inventory)
    {
        this.inventory = inventory;
        inventory.OnInventoryChanged += Refresh;
        toolbarSystem.OnSelectedIndexChanged += HighlightToolbarSlot;

        Refresh();
    }

    public void Refresh()
    {
        ClearSlots();

        for (int i = 0; i < inventorySlots.Length; i++)
        {
            var item = inventory.GetItemAt(i);
            var slot = inventorySlots[i];

            if (item != null)
            {
                SpawnItem(item, slot, i);
            }
        }

        HighlightToolbarSlot(toolbarSystem.SelectedIndex);
    }

    private void ClearSlots()
    {
        foreach (var kvp in slotToItemMap)
        {
            if (kvp.Value != null)
                Destroy(kvp.Value.gameObject);
        }
        slotToItemMap.Clear();
    }

    private void SpawnItem(InventoryItem item, InventorySlotUI slot, int index)
    {
        GameObject go = Instantiate(inventoryItemPrefab, slot.transform);
        InventoryItemUI itemUI = go.GetComponent<InventoryItemUI>();
        itemUI.Initialize(item, index, this);
        slotToItemMap[slot] = itemUI;
    }

    public void HandleItemDrop(InventoryItemUI itemUI, PointerEventData eventData)
    {
        if (itemUI == null || eventData == null) return;

        InventorySlotUI fromSlot = inventorySlots[itemUI.SlotIndex];
        InventorySlotUI toSlot = eventData.pointerCurrentRaycast.gameObject?.GetComponentInParent<InventorySlotUI>();

        if (fromSlot == null || toSlot == null || fromSlot == toSlot) return;

        int fromIndex = GetSlotIndex(fromSlot);
        int toIndex = GetSlotIndex(toSlot);

        inventory.SwapItems(fromIndex, toIndex);
    }

    private int GetSlotIndex(InventorySlotUI slot)
    {
        for (int i = 0; i < inventorySlots.Length; i++)
        {
            if (inventorySlots[i] == slot)
                return i;
        }
        return -1;
    }

    private void HighlightToolbarSlot(int index)
    {
        if (selectionHighlight == null || index < 0 || index >= inventorySlots.Length)
            return;

        selectionHighlight.SetParent(inventorySlots[index].transform, false);
        selectionHighlight.SetAsFirstSibling();
        selectionHighlight.localPosition = Vector3.zero;
        selectionHighlight.localRotation = Quaternion.identity;
        selectionHighlight.localScale = Vector3.one;
        selectionHighlight.gameObject.SetActive(true);
    }
}