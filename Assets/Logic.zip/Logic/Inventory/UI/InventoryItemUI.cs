using UnityEngine;
using UnityEngine.EventSystems;

public class InventoryItemUI : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    public int SlotIndex { get; private set; }
    public InventoryItem Item { get; private set; }
    private InventoryUIManager uiManager;

    public void Initialize(InventoryItem item, int index, InventoryUIManager manager)
    {
        Item = item;
        SlotIndex = index;
        uiManager = manager;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        // Optional visuals: scale, ghost image, etc.
        transform.SetParent(transform.root); // detach so it doesn't get clipped by slot
    }

    public void OnDrag(PointerEventData eventData)
    {
        transform.position = eventData.position;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        uiManager?.HandleItemDrop(this, eventData);
    }
}