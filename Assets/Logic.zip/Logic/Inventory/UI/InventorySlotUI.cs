using UnityEngine;
using UnityEngine.EventSystems;

public class InventorySlotUI : MonoBehaviour, IDropHandler
{
    public void OnDrop(PointerEventData eventData)
    {
        var dropped = eventData.pointerDrag?.GetComponent<InventoryItemUI>();
        if (dropped != null)
        {
            dropped.transform.SetParent(transform);
        }
    }
}