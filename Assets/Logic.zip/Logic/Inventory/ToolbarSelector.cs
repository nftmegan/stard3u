// ToolbarSelector.cs
using UnityEngine;
using System;

public class ToolbarSelector : MonoBehaviour
{
    [SerializeField] private int maxToolbarSlots = 9;

    private Inventory inventory;
    private int[] toolbarSlotToInventoryIndex;

    public int SelectedIndex { get; private set; } = 0;

    public event Action<InventoryItem> OnSelectedItemChanged;
    public event Action<int> OnSelectedIndexChanged;

    private void Awake()
    {
        toolbarSlotToInventoryIndex = new int[maxToolbarSlots];
        for (int i = 0; i < maxToolbarSlots; i++)
            toolbarSlotToInventoryIndex[i] = i;
    }

    public void SetInventory(Inventory newInventory)
    {
        if (inventory != null)
            inventory.OnInventoryChanged -= HandleInventoryChanged;

        inventory = newInventory;

        if (inventory != null)
        {
            inventory.OnInventoryChanged += HandleInventoryChanged;
            HandleInventoryChanged();
        }
    }

    public void HandleInput(IPlayerInput input)
    {
        if (input.ScrollDelta != 0)
            Scroll(-input.ScrollDelta);

        if (input.NumberKeyPressed > 0)
            SelectByIndex(input.NumberKeyPressed - 1);
    }

    public void Scroll(int direction)
    {
        int newIndex = Mathf.Clamp(SelectedIndex + direction, 0, maxToolbarSlots - 1);
        if (newIndex != SelectedIndex)
            SelectByIndex(newIndex);
    }

    public void SelectByIndex(int toolbarSlotIndex)
    {
        if (toolbarSlotIndex >= 0 && toolbarSlotIndex < maxToolbarSlots)
        {
            SelectedIndex = toolbarSlotIndex;
            FireSelectionChanged();
        }
    }

    private void FireSelectionChanged()
    {
        int invIndex = toolbarSlotToInventoryIndex[SelectedIndex];
        InventoryItem item = (inventory != null && invIndex < inventory.GetSlotCount()) ? inventory.GetItemAt(invIndex) : null;
        OnSelectedItemChanged?.Invoke(item);
        OnSelectedIndexChanged?.Invoke(SelectedIndex);
    }

    private void HandleInventoryChanged()
    {
        FireSelectionChanged();
    }

    public int GetInventoryIndex(int toolbarSlot) => toolbarSlotToInventoryIndex[toolbarSlot];

    public void SwapToolbarMapping(int slotA, int slotB)
    {
        if (slotA == slotB) return;
        (toolbarSlotToInventoryIndex[slotA], toolbarSlotToInventoryIndex[slotB]) = (toolbarSlotToInventoryIndex[slotB], toolbarSlotToInventoryIndex[slotA]);
        FireSelectionChanged();
    }
}