// ========================
// IRuntimeItem.cs
// ========================
public interface IRuntimeItem
{
    ItemData GetItemData();
    void SetItemData(ItemData data);
}
