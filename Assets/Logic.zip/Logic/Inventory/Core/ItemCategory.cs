// ========================
// ItemCategory.cs
// ========================
public enum ItemCategory
{
    Generic,
    Weapon,
    Tool,
    Ammo,
    Resource,
    Container,
    Attachment,
    KeyItem
}
