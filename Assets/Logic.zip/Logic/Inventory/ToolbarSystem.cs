using UnityEngine;
using System;

public class ToolbarSystem : MonoBehaviour
{
    [SerializeField] private Inventory inventory;
    [SerializeField] private int maxSlots = 9;

    public int SelectedIndex { get; private set; } = 0;

    public InventoryItem SelectedItem => inventory.GetToolbarItems(maxSlots)[SelectedIndex];

    public event Action<InventoryItem> OnSelectedItemChanged;
    public event Action<int> OnSelectedIndexChanged;

    public void HandleInput(IPlayerInput input)
    {
        if (input.ScrollDelta != 0)
            Scroll(-input.ScrollDelta);

        if (input.NumberKeyPressed > 0)
            SelectByIndex(input.NumberKeyPressed - 1);
    }

    public void Scroll(int delta)
    {
        int newIndex = Mathf.Clamp(SelectedIndex + delta, 0, maxSlots - 1);
        if (newIndex != SelectedIndex)
            SelectByIndex(newIndex);
    }

    public void SelectByIndex(int index)
    {
        if (index < 0 || index >= maxSlots) return;

        SelectedIndex = index;
        OnSelectedItemChanged?.Invoke(SelectedItem);
        OnSelectedIndexChanged?.Invoke(index);
    }
}