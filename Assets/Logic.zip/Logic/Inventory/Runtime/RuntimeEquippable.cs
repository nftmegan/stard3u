// ========================
// RuntimeEquippable.cs
// ========================
using UnityEngine;

public class RuntimeEquippable : MonoBehaviour, IRuntimeItem
{
    [SerializeField] private string itemCode;
    private ItemData runtimeItemInstance;

    public string GetItemCode() => itemCode;
    public ItemData GetItemData() => runtimeItemInstance;
    public void SetItemData(ItemData item) => runtimeItemInstance = item;
}
