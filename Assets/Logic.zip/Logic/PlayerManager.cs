using UnityEngine;
using System;

public class PlayerManager : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private InventoryUIManager inventoryUIManager;
    [SerializeField] private ToolbarSystem toolbarSystem;
    [SerializeField] private Inventory playerInventory;
    [SerializeField] private Transform characterOrientation;

    public PlayerOrientation Orientation { get; private set; }
    public MyCharacterController MyCharacterController { get; private set; }
    public HeadBob HeadBob { get; private set; }
    public IPlayerInput InputProvider { get; private set; }

    private EquipmentController equipmentController;
    private WorldInteractor worldInteractor;

    private void Awake()
    {
        Orientation = GetComponent<PlayerOrientation>();
        MyCharacterController = GetComponentInChildren<MyCharacterController>();
        HeadBob = GetComponentInChildren<HeadBob>();
        equipmentController = GetComponentInChildren<EquipmentController>();
        worldInteractor = GetComponentInChildren<WorldInteractor>();

        InputProvider = GetComponent<IPlayerInput>();
        if (InputProvider == null)
            Debug.LogError("PlayerManager: No IPlayerInput found.");

        // If toolbarSelector or inventoryUIManager were not assigned manually, try auto-assign
        if (toolbarSystem == null)
            toolbarSystem = GetComponentInChildren<ToolbarSystem>();
        if (inventoryUIManager == null)
            inventoryUIManager = FindObjectOfType<InventoryUIManager>();
    }

    private void Start()
    {
        if (playerInventory == null)
            playerInventory = GetComponent<Inventory>();

        if (playerInventory == null)
        {
            Debug.LogError("PlayerManager: No Inventory assigned or found.");
            return;
        }

        if (inventoryUIManager != null)
            inventoryUIManager.Initialize(playerInventory);
        else
            Debug.LogError("PlayerManager: InventoryUIManager not assigned.");
    }

    private void Update()
    {
        if (Orientation == null || characterOrientation == null || MyCharacterController == null || InputProvider == null)
            return;

        Orientation.ApplyLookInput(InputProvider.LookAxisX, InputProvider.LookAxisY);
        characterOrientation.rotation = Quaternion.Euler(Orientation.Pitch, Orientation.Yaw, 0f);

        Vector3 lookDir = Orientation.CurrentOrientation * Vector3.forward;

        MyCharacterController.HandleInput(InputProvider, lookDir);
        equipmentController?.HandleInput(InputProvider);
        toolbarSystem?.HandleInput(InputProvider);
        worldInteractor?.HandleInput(InputProvider);
    }

    private void LateUpdate()
    {
        if (MyCharacterController != null && characterOrientation != null)
        {
            characterOrientation.position = MyCharacterController.GetSmoothedHeadWorldPosition();
        }
    }

    // === Public Accessors ===
    public Inventory GetInventory() => playerInventory;
    public ToolbarSystem GetToolbarSelector() => toolbarSystem;
    public WorldInteractor GetWorldInteractor() => worldInteractor;

    public void SetSlowWalk(bool value)
    {
        MyCharacterController?.ForceSlowWalk(value);
    }

    // === Inventory Selection Subscription ===
    public void SubscribeToInventorySelection(Action<InventoryItem> callback)
    {
        if (toolbarSystem != null)
            toolbarSystem.OnSelectedItemChanged += callback;
        else
            Debug.LogWarning("PlayerManager: Tried to subscribe to inventory selection, but toolbarSelector is null.");
    }

    public void UnsubscribeFromInventorySelection(Action<InventoryItem> callback)
    {
        if (toolbarSystem != null)
            toolbarSystem.OnSelectedItemChanged -= callback;
    }

    // === Cursor Locking ===
    private void LockCursor()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void UnlockCursor()
    {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }
}
