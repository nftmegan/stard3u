using System.Collections.Generic;
using UnityEngine;

public class EquipmentController : MonoBehaviour
{
    [Header("Equippable Item Holder")]
    [Tooltip("Parent of all runtime equippable objects, including hands.")]
    public Transform itemHolder;

    [Header("References")]
    [SerializeField] private EquipTransitionAnimator equipAnimator;
    [Tooltip("Special item code used for 'hands'.")]
    [SerializeField] private string handsItemCode = "hands";

    private PlayerManager playerManager;

    private readonly Dictionary<string, GameObject> itemPrefabByCode = new();
    private GameObject currentItemObject;
    private IItemInputReceiver currentInputReceiver;
    private InventoryItem equippedInventoryItem;
    private InventoryItem pendingItemToEquip;
    private bool isSwapping = false;

    public InventoryItem EquippedItem => equippedInventoryItem;

    private void Awake()
    {
        playerManager = GetComponentInParent<PlayerManager>();
        RegisterAllEquippableObjects();
    }

    private void Start()
    {
        playerManager?.SubscribeToInventorySelection(TryEquipItem);
    }

    private void RegisterAllEquippableObjects()
    {
        itemPrefabByCode.Clear();

        if (itemHolder == null)
        {
            Debug.LogError("EquipmentController: itemHolder is not assigned.");
            return;
        }

        foreach (Transform child in itemHolder)
        {
            if (child.TryGetComponent(out RuntimeEquippable runtime))
            {
                string code = runtime.GetItemCode();
                if (!string.IsNullOrEmpty(code))
                {
                    itemPrefabByCode[code] = child.gameObject;
                    child.gameObject.SetActive(false);
                }
            }
        }
    }

    public void HandleInput(IPlayerInput input)
    {
        if (isSwapping || currentInputReceiver == null) return;

        if (input.Fire1Down) currentInputReceiver.OnFire1Down();
        if (input.Fire1Hold) currentInputReceiver.OnFire1Hold();
        if (input.Fire1Up) currentInputReceiver.OnFire1Up();

        if (input.Fire2Down) currentInputReceiver.OnFire2Down();
        if (input.Fire2Hold) currentInputReceiver.OnFire2Hold();
        if (input.Fire2Up) currentInputReceiver.OnFire2Up();

        if (input.UtilityDown) currentInputReceiver.OnUtilityDown();
        if (input.UtilityUp) currentInputReceiver.OnUtilityUp();

        if (input.ReloadDown) currentInputReceiver.OnReloadDown();
    }

    private void TryEquipItem(InventoryItem item)
    {
        if (isSwapping)
        {
            pendingItemToEquip = item;
            return;
        }

        if (item?.data == null || !itemPrefabByCode.TryGetValue(item.data.itemCode, out var prefab))
        {
            EquipPrefabByCode(handsItemCode, null);
            return;
        }

        EquipPrefabByCode(item.data.itemCode, item);
    }

    private void EquipPrefabByCode(string itemCode, InventoryItem item)
    {
        if (!itemPrefabByCode.TryGetValue(itemCode, out var prefab))
        {
            Debug.LogWarning($"Equip failed: prefab for '{itemCode}' not found.");
            return;
        }

        bool isSamePrefab = currentItemObject == prefab;
        bool isSameRuntimeItem = item == equippedInventoryItem;

        if (isSamePrefab && isSameRuntimeItem)
            return;

        isSwapping = true;
        pendingItemToEquip = null;

        if (currentItemObject != null)
            currentItemObject.SetActive(false);

        prefab.SetActive(true);

        if (equipAnimator != null)
        {
            equipAnimator.Play(() =>
            {
                CompleteEquip(prefab, item);
                isSwapping = false;

                if (pendingItemToEquip != null)
                    TryEquipItem(pendingItemToEquip);
            });
        }
        else
        {
            CompleteEquip(prefab, item);
            isSwapping = false;
        }
    }

    private void CompleteEquip(GameObject instance, InventoryItem item)
    {
        currentItemObject = instance;
        currentInputReceiver = instance.GetComponent<IItemInputReceiver>();
        equippedInventoryItem = item;

        if (instance.TryGetComponent(out IRuntimeItem runtimeItem))
        {
            runtimeItem.SetItemData(item?.data);
        }

        if (instance.TryGetComponent(out IInventoryUser inventoryUser))
        {
            inventoryUser.SetInventory(playerManager?.GetInventory());
        }
    }

    public void SetForceSlowWalk(bool value)
    {
        playerManager?.SetSlowWalk(value);
    }

    public GameObject GetCurrentItemObject() => currentItemObject;
    public IItemInputReceiver GetCurrentInputReceiver() => currentInputReceiver;
}
